## Installation

Run 
```pip install similarity_checker```